from .procedures import *


jni_invoke_interface = [
        'reserved1',
        'reserved2',
        'reserved3',

        'DestroyJavaVM',
        'AttachCurrentThread',
        'DetachCurrentThread',

        'GetEnv',

        'AttachCurrentThreadAsDaemon'
        ]

