export function log(message: any): void {
    console.log(message);
}
