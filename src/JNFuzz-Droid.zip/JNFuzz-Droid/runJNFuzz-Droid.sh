python3 main.py -i apk -o out -a
