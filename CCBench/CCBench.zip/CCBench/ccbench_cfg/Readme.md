no cfg

+ math_library.apk: JN-SAF model Semantics failed

+ native_method_overloading1.apk: JN-SAF resolve the native method failed.

+ arm64_v8a.apk: JN-SAF can't deal the arm64-v8a arch.
